package Model;

import java.util.ArrayList;
import java.util.Scanner;

import com.bloomberglp.blpapi.Session;


/**
 *
 * @author laurenastell
 *
 */
public class Model {
	
	public static void main(String[] args) {
		
		//create the connection with the database
		CreateConnection c = new CreateConnection();
		
		//get the session 
		Session session = c.getSession();
		
		//to hold all the different search queries we want to run
		ArrayList<ArrayList<ArrayList<String>>> dataOptions = getOptions(session);
		
		//displays chart options 
		
		//open input stream 
		Scanner input = new Scanner(System.in);
		int userInput;
		
		//Loop unitl the user ends with -1
		while ((userInput = input.nextInt()) != -1) {
			
		}
		
	}
	
	/**
	 * Calls the different search queries to be displayed
	 * @param session
	 * @return
	 */
	private static ArrayList<ArrayList<ArrayList<String>>> getOptions(Session session) {
		ArrayList<ArrayList<ArrayList<String>>> dO = new ArrayList<ArrayList<ArrayList<String>>>();
		
		return dO;
	}
	
	private static void displayOptions(ArrayList<ArrayList<ArrayList<String>>> options) {
		
	}
	
	
}
